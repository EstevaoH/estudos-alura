<p align="center"> <img src="https://user-images.githubusercontent.com/76708357/162738129-a9aa3391-385f-403d-8f36-6324549ff735.png" alt="Tailwind CSS: estilizando páginas com classes utilitárias"> </p>

<hr>

<p align="center"> <img src="https://user-images.githubusercontent.com/76708357/162738365-c3bbc527-11ca-4626-9073-91a225f13534.png" alt="Alura Newsletter"> </p>
<p align="center">Um site que simula a tela de inscrição da newsletter da Alura, um serviço que tem o objetivo de fornecer informações e novidades sobre o universo tech.</p>

## Tecnologias
* HTML
* Tailwind CSS

## Desktop
![image](https://user-images.githubusercontent.com/76708357/162736350-2c71a443-f157-42ec-8e3f-bd62d2889b39.png)

## Mobile
![image](https://user-images.githubusercontent.com/76708357/162736513-dc021074-a2e5-4a19-8715-23b8706a5638.png)
